# My Readme

Target: {{ target }}

# INVENTORY

```
{{inventory.classes | yaml }}
```


```
{{inventory.parameters | yaml }}
```
